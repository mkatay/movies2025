import React from 'react'
import { PageLayout } from '../components/PageLayout'

export const SearchPage = () => {
  return (
      <PageLayout title="Search page">
      {/* Ide jön majd a filmek kártyánként */}
    </PageLayout>
  )
}


