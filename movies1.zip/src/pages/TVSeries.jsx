import React from 'react'
import { PageLayout } from '../components/PageLayout'

export const TVSeries = () => {
  return (
      <PageLayout title="TV Series">
      {/* Ide jön majd a filmek kártyánként */}
    </PageLayout>
  )
}


