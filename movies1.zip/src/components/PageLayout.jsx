import { Container, Typography, Box } from '@mui/material'
import React from 'react'

export const PageLayout = ({ title, children }) => {
  return (
    <Container maxWidth={false}
      sx={{minHeight: '100vh',display: 'flex',flexDirection: 'column',
        background: 'linear-gradient(to right, #141E30, #243B55)',
        color: 'white', pt: '1rem', pb: '60px'  }} // hagyunk helyet a BottomNav miatt
    >
      <Typography variant="h3"align="center"  sx={{fontWeight: 'bold',textTransform: 'uppercase',letterSpacing: 2,
          background: 'linear-gradient(45deg, #ff6b6b, #f8e71c, #4cd137)',
          WebkitBackgroundClip: 'text',WebkitTextFillColor: 'transparent'}}
      >
        {title}
      </Typography>
      <Box >
        {children}
      </Box>
    </Container>
  )
}
