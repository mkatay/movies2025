import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import CardActionArea from '@mui/material/CardActionArea';
import CardActions from '@mui/material/CardActions';
import { img_300 } from '../utils';

export const MyCard=({backdrop_path,original_title,release_date,vote_average})=>{
    const voteStyle={
        position:'absolute',
        top:115,right:10,
        width:'30px',
        height:'30px',
        borderRadius:'50%',
        border:'1px solid white',
        display:'flex',
        justifyContent:'center',
        alignItems:'center',
        color:'white',
        backgroundColor:"#141E30",
        fontSize:'0.8rem'
    }
  return (
    <Card sx={{ width: 300,position:'relative',background:'#243B55',color:'white' }}>
      <CardActionArea>
        <CardMedia
          component="img"
          height="140"
          image={`${img_300+'/'+backdrop_path}`}
          alt={original_title}
        />
        <CardContent >
          <Typography gutterBottom variant="h6" component="div">
            {original_title}
          </Typography>
          <Typography variant="body2" sx={{textAlign:'right'}}>
            {release_date}
          </Typography>
          <Typography sx={voteStyle} >{vote_average.toFixed(1)}</Typography>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}
